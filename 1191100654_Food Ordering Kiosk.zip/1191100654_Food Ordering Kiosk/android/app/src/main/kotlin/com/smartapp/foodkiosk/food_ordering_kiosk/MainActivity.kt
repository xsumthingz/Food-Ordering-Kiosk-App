package com.smartapp.foodkiosk.food_ordering_kiosk

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
