# Food Ordering Kiosk App

## Project Information
Project Title: Food Ordering Kiosk  
Project Done By: SARVIEN A/L MANISELVAM  
Student ID: 1191100654  
Faculty: Faculty of Information Science and Technology (FIST)

## Description
A food ordering kiosk application built using Flutter for the frontend and Firebase for backend services (authentication, Firestore database, and cloud storage).

## Requirements
- Flutter SDK: 3.8.1 or later  
  Download: https://docs.flutter.dev/get-started/install
- Dart SDK (bundled with Flutter)
- Firebase account: https://firebase.google.com/
- Android Studio or Visual Studio Code (for development and emulator)
- Git (for cloning the repository)

## Dependencies
Install dependencies using:
flutter pub get


Key packages used:
- flutter (SDK)
- cupertino_icons: ^1.0.8
- firebase_core: ^4.0.0
- cloud_firestore: ^6.0.0
- provider: ^6.1.5

Dev dependencies:
- flutter_test (SDK)
- flutter_lints: ^5.0.0
- flutter_launcher_icons: ^0.13.1

(See `pubspec.yaml` for full details.)

## Setup Instructions
1. **Clone the repository**
git clone https://github.com/)
cd food_ordering_kiosk


2. **Install dependencies**
flutter pub get


3. **Configure Firebase**
- Create a new Firebase project in the Firebase Console.
- Enable Authentication (Email/Password or other providers).
- Enable Firestore Database.
- Enable Firebase Storage (for images).
- Download `google-services.json` (for Android) and place it in `android/app/`.
- Download `GoogleService-Info.plist` (for iOS) and place it in `ios/Runner/`.
- **Important:** Do not hardcode credentials. Use the official Firebase config files above.

Guide: https://firebase.google.com/docs/flutter/setup

4. **Run the app**
flutter run


## Database Notes
- No external dataset is required.
- The app uses Firebase Firestore as its database.
- You can create a `menu` collection in Firestore with documents representing food items:
Example document fields:
- `name`: ""
- `price`: 
- `image_url`: "link-to-firebase-storage-image"
- `category`: ""

## Links
- Flutter SDK: https://docs.flutter.dev/get-started/install
- Firebase Setup Guide: https://firebase.google.com/docs/flutter/setup
- GitHub Repository (source code): https://github.com/your-username/food_ordering_kiosk
