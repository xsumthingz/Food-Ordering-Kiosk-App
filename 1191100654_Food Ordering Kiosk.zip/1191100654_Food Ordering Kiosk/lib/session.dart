class Session {
  static String? currentAdminId;
}