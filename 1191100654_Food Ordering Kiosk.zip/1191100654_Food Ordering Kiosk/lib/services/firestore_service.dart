import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/menu_item.dart';
import '../models/cart_item.dart';

class FirestoreService {
  static final _db = FirebaseFirestore.instance;

  static Stream<List<MenuItem>> streamMenu() {
    return _db
        .collection('menu')
        .where('isActive', isEqualTo: true)
        .orderBy('name')
        .snapshots()
        .map((snap) => snap.docs.map((doc) => MenuItem.fromMap(doc.id, doc.data() as Map<String, dynamic>)).toList());
  }

  static Future<void> addMenuItem({
    required String name,
    required double price,
    bool isActive = true,
    String? imageUrl,
    required String category,
  }) async {
    try {
      print('🔄 SAVING TO FIREBASE...');
      print('📝 Data: name=$name, price=$price, category=$category');

      final result = await _db.collection('menu').add({
        'name': name,
        'price': price,
        'isActive': isActive,
        'imageUrl': imageUrl,
        'category': category,
        'createdAt': FieldValue.serverTimestamp(),
      });

      print('✅ SUCCESS! Document ID: ${result.id}');

    } catch (e) {
      print('❌ FIREBASE ERROR: $e');
      rethrow;
    }
  }

  static Future<void> updateAvailability(String id, bool isActive) async {
    await _db.collection('menu').doc(id).update({'isActive': isActive});
  }

  static Future<void> deleteMenuItem(String id) async {
    await _db.collection('menu').doc(id).delete();
  }

  static Future<bool> validateAdmin(String adminId) async {
    final doc = await _db.collection('admins').doc(adminId).get();
    return doc.exists;
  }

  // NEW: Get the next sequential order number
  static Future<int> _getNextOrderNumber() async {
    try {
      // Get the counter document
      final counterRef = _db.collection('counters').doc('orderCounter');

      // Use Firestore transaction to ensure atomic increment
      final result = await _db.runTransaction<int>((transaction) async {
        final counterDoc = await transaction.get(counterRef);
        int currentNumber = 1;

        if (counterDoc.exists) {
          currentNumber = (counterDoc.data()?['lastNumber'] ?? 0) + 1;
        }

        // Update the counter
        transaction.set(counterRef, {'lastNumber': currentNumber});

        return currentNumber;
      });

      return result;
    } catch (e) {
      print('Error getting order number: $e');
      // Fallback: use timestamp if counter fails
      return DateTime.now().millisecondsSinceEpoch % 10000;
    }
  }

  static Future<Map<String, dynamic>> createOrder({
    required List<CartItem> cart,
    required double total,
    required String paymentMethod,
  }) async {
    try {
      // Get the next sequential order number
      final orderNumber = await _getNextOrderNumber();
      final formattedOrderNumber = orderNumber.toString().padLeft(4, '0');

      // Create order data
      final orderData = {
        'orderNumber': formattedOrderNumber, // 4-digit number
        'items': cart.map((c) => {
          'itemId': c.item.id,
          'name': c.item.name,
          'qty': c.qty,
          'price': c.item.price,
        }).toList(),
        'total': total,
        'paymentMethod': paymentMethod,
        'status': 'received',
        'isPaid': paymentMethod != 'cash', // Cash orders start as unpaid
        'createdAt': FieldValue.serverTimestamp(),
      };

      // Save to Firestore
      final ref = _db.collection('orders').doc();
      await ref.set(orderData);

      // Return both the document ID and order number
      return {
        'docId': ref.id,
        'orderNumber': formattedOrderNumber,
      };

    } catch (e) {
      print('Error creating order: $e');
      rethrow;
    }
  }

  static Stream<QuerySnapshot> streamOrders() {
    return _db.collection('orders').orderBy('createdAt', descending: true).snapshots();
  }

  static Future<void> updateOrderStatus(String orderId, String status) async {
    await _db.collection('orders').doc(orderId).update({
      'status': status,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  // NEW: Update payment status for cash orders
  static Future<void> updatePaymentStatus(String orderId, bool isPaid) async {
    await _db.collection('orders').doc(orderId).update({
      'isPaid': isPaid,
      'paymentVerifiedAt': FieldValue.serverTimestamp(),
    });
  }
}