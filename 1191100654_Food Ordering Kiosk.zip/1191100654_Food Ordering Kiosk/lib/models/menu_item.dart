class MenuItem {
  final String id;
  final String name;
  final double price;
  final bool isActive;
  final String? imageUrl;
  final String? category; // Add this

  MenuItem({
    required this.id,
    required this.name,
    required this.price,
    required this.isActive,
    this.imageUrl,
    this.category, // Add this
  });

  factory MenuItem.fromMap(String id, Map<String, dynamic> data) => MenuItem(
    id: id,
    name: data['name'] ?? '',
    price: (data['price'] as num).toDouble(),
    isActive: data['isActive'] ?? true,
    imageUrl: data['imageUrl'],
    category: data['category'], // Add this
  );
}