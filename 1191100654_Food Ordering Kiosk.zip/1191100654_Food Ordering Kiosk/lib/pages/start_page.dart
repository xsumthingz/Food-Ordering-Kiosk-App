import 'package:flutter/material.dart';
import 'menu_page.dart';
import 'login_page.dart';

class StartPage extends StatelessWidget {
  static const route = '/start';
  const StartPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Welcome")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () => Navigator.pushReplacementNamed(context, MenuPage.route),
              child: const Text("Continue as Guest"),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () => Navigator.pushNamed(context, LoginPage.route),
              child: const Text("Login / Register"),
            ),
          ],
        ),
      ),
    );
  }
}
