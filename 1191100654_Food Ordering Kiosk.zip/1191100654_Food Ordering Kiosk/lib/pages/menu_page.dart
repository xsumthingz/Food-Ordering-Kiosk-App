import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/firestore_service.dart';
import '../models/menu_item.dart';
import '../providers/cart_provider.dart';
import 'cart_page.dart';
import 'admin_page.dart';
import 'welcome_page.dart';

class MenuPage extends StatefulWidget {
  static const route = '/';
  const MenuPage({super.key});

  @override
  State<MenuPage> createState() => _MenuPageState();
}

class _MenuPageState extends State<MenuPage> {
  late PageController _promoController;
  int _currentPromoIndex = 0;

  // Add this key to prevent rebuilding
  final GlobalKey _gridKey = GlobalKey();

  @override
  void initState() {
    super.initState();
    _promoController = PageController(viewportFraction: 0.9);
  }

  @override
  void dispose() {
    _promoController.dispose();
    super.dispose();
  }

  Future<void> _openAdminLogin() async {
    final controller = TextEditingController();
    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Admin Login'),
        content: TextField(
          controller: controller,
          keyboardType: TextInputType.number,
          maxLength: 4,
          decoration: const InputDecoration(labelText: 'Admin ID'),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () async {
              if (controller.text.length == 4 &&
                  await FirestoreService.validateAdmin(controller.text)) {
                Navigator.pop(ctx);
                Navigator.pushNamed(context, AdminPage.route);
              }
            },
            child: const Text('Login'),
          ),
        ],
      ),
    );
  }

  void _showQuantityDialog(MenuItem item, CartProvider cart) {
    int quantity = 1;

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          title: Text('Add ${item.name}'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('RM ${item.price.toStringAsFixed(2)}',
                  style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.orange)),
              const SizedBox(height: 16),
              const Text('Select Quantity:',
                  style: TextStyle(fontSize: 16)),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  IconButton(
                    icon: const Icon(Icons.remove),
                    onPressed: quantity > 1
                        ? () => setState(() => quantity--)
                        : null,
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20, vertical: 8),
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.orange),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text('$quantity',
                        style: const TextStyle(
                            fontSize: 18, fontWeight: FontWeight.bold)),
                  ),
                  IconButton(
                    icon: const Icon(Icons.add),
                    onPressed: () => setState(() => quantity++),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text('Total: RM ${(item.price * quantity).toStringAsFixed(2)}',
                  style: const TextStyle(
                      fontSize: 16, fontWeight: FontWeight.bold)),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                for (int i = 0; i < quantity; i++) {
                  cart.add(item);
                }
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Added $quantity ${item.name} to cart'),
                    duration: const Duration(seconds: 2),
                  ),
                );
              },
              child: const Text('Add to Cart'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();

    return DefaultTabController(
      length: 4,
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Colors.white,
          elevation: 1,
          title: const Text('Food Menu',
              style: TextStyle(
                  fontWeight: FontWeight.bold, color: Colors.black)),
          bottom: TabBar(
            tabs: const [
              Tab(text: 'FOOD'),
              Tab(text: 'COMBOS'),
              Tab(text: 'FRIED ITEMS'),
              Tab(text: 'BEVERAGE'),
            ],
            labelStyle:
            const TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
            indicatorColor: Colors.orange,
            labelColor: Colors.orange,
            unselectedLabelColor: Colors.grey,
            isScrollable: true,
          ),
          leading: IconButton(
            icon: const Icon(Icons.home, color: Colors.black),
            onPressed: () {
              Navigator.pushReplacementNamed(context, WelcomePage.route);
            },
            tooltip: 'Back to Welcome',
          ),
          actions: [
            IconButton(
                icon: const Icon(Icons.admin_panel_settings,
                    color: Colors.black),
                onPressed: _openAdminLogin),
            Stack(
              children: [
                IconButton(
                    icon: const Icon(Icons.shopping_cart,
                        color: Colors.black),
                    onPressed: () =>
                        Navigator.pushNamed(context, CartPage.route)),
                if (cart.items.isNotEmpty)
                  Positioned(
                    right: 8,
                    top: 8,
                    child: CircleAvatar(
                      radius: 8,
                      backgroundColor: Colors.red,
                      child: Text(
                        cart.items.length.toString(),
                        style: const TextStyle(
                            fontSize: 10, color: Colors.white),
                      ),
                    ),
                  ),
              ],
            ),
          ],
        ),
        body: Column(
          children: [
            // Promo Banner - SEPARATED from main build with its own state
            _PromoSlider(
              currentIndex: _currentPromoIndex,
              onPageChanged: (index) {
                setState(() {
                  _currentPromoIndex = index;
                });
              },
            ),
            const SizedBox(height: 8),

            // Dot indicators
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(5, (index) {
                return Container(
                  width: 8,
                  height: 8,
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _currentPromoIndex == index
                        ? Colors.orange
                        : Colors.grey[300],
                  ),
                );
              }),
            ),
            const SizedBox(height: 8),

            // Tab View - Wrapped with key to prevent rebuild
            Expanded(
              child: TabBarView(
                children: [
                  _CategoryTab(key: _gridKey, category: 'Food'),
                  _CategoryTab(key: GlobalKey(), category: 'Combos'),
                  _CategoryTab(key: GlobalKey(), category: 'Fried Items'),
                  _CategoryTab(key: GlobalKey(), category: 'Beverage'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// SEPARATE WIDGET for promo slider to isolate rebuilds
class _PromoSlider extends StatefulWidget {
  final int currentIndex;
  final ValueChanged<int> onPageChanged;

  const _PromoSlider({
    required this.currentIndex,
    required this.onPageChanged,
  });

  @override
  State<_PromoSlider> createState() => _PromoSliderState();
}

class _PromoSliderState extends State<_PromoSlider> {
  late PageController _controller;

  @override
  void initState() {
    super.initState();
    _controller = PageController(viewportFraction: 0.9);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final promoImages = [
      'https://says.com/my/_next/image?url=https%3A%2F%2Fmedia.says.com%2F2025%2F03%2F1c2a.png&w=1920&q=75',
      'https://www.maggi.my/sites/default/files/styles/srh_recipes/public/srh_recipes/c58a205b06e53cf566850edf8aeed6c1.jpg?h=68f5af4e&itok=j9MdMZCz',
      'https://www.awesomecuisine.com/wp-content/uploads/2008/02/idiyappam.jpg',
      'http://3.bp.blogspot.com/-WCu46VxomPw/TppVb5c0lcI/AAAAAAAAIzI/RMaEX59Gafk/s1600/DSCN4496.jpg',
      'https://images.unsplash.com/photo-1476224203421-9ac39bcb3327?w=400',
    ];

    return SizedBox(
      height: 150,
      child: PageView.builder(
        controller: _controller,
        itemCount: promoImages.length,
        onPageChanged: widget.onPageChanged,
        physics: const PageScrollPhysics(parent: BouncingScrollPhysics()),
        itemBuilder: (context, index) {
          return Container(
            margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              image: DecorationImage(
                image: NetworkImage(promoImages[index]),
                fit: BoxFit.cover,
              ),
            ),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                gradient: const LinearGradient(
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                  colors: [Colors.black54, Colors.transparent],
                ),
              ),
              child: Align(
                alignment: Alignment.bottomLeft,
                child: Padding(
                  padding: const EdgeInsets.all(8),
                  child: Text(
                    'Special ${index + 1}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

// SEPARATE WIDGET for category tab to prevent rebuilds
class _CategoryTab extends StatefulWidget {
  final String category;

  const _CategoryTab({
    Key? key,
    required this.category,
  }) : super(key: key);

  @override
  State<_CategoryTab> createState() => _CategoryTabState();
}

class _CategoryTabState extends State<_CategoryTab> with AutomaticKeepAliveClientMixin {
  @override
  bool get wantKeepAlive => true; // This keeps the tab alive when switching

  @override
  Widget build(BuildContext context) {
    super.build(context); // Required for AutomaticKeepAliveClientMixin
    final cart = Provider.of<CartProvider>(context);

    return StreamBuilder<List<MenuItem>>(
      stream: FirestoreService.streamMenu(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(
            child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Colors.orange),
            ),
          );
        }

        if (snapshot.hasError) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.error, color: Colors.red, size: 48),
                const SizedBox(height: 16),
                Text('Error loading menu: ${snapshot.error}',
                    textAlign: TextAlign.center),
              ],
            ),
          );
        }

        final items = snapshot.data ?? [];

        // Filter by category field
        final displayItems = items
            .where((item) =>
        item.category?.toLowerCase() == widget.category.toLowerCase())
            .toList();

        if (displayItems.isEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.fastfood,
                    size: 48, color: Colors.grey[400]),
                const SizedBox(height: 16),
                Text('No ${widget.category} available',
                    style: TextStyle(
                        fontSize: 16, color: Colors.grey[600])),
              ],
            ),
          );
        }

        return GridView.builder(
          key: PageStorageKey(widget.category), // Preserve scroll position
          padding: const EdgeInsets.all(12),
          gridDelegate:
          const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 6,
            mainAxisSpacing: 6,
            childAspectRatio: 0.68,
          ),
          itemCount: displayItems.length,
          itemBuilder: (context, index) => MenuItemCard(
            item: displayItems[index],
            cart: cart,
            onAddToCart: () => _showQuantityDialog(displayItems[index], cart),
          ),
        );
      },
    );
  }

  void _showQuantityDialog(MenuItem item, CartProvider cart) {
    int quantity = 1;

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          title: Text('Add ${item.name}'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('RM ${item.price.toStringAsFixed(2)}',
                  style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.orange)),
              const SizedBox(height: 16),
              const Text('Select Quantity:',
                  style: TextStyle(fontSize: 16)),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  IconButton(
                    icon: const Icon(Icons.remove),
                    onPressed: quantity > 1
                        ? () => setState(() => quantity--)
                        : null,
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20, vertical: 8),
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.orange),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text('$quantity',
                        style: const TextStyle(
                            fontSize: 18, fontWeight: FontWeight.bold)),
                  ),
                  IconButton(
                    icon: const Icon(Icons.add),
                    onPressed: () => setState(() => quantity++),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text('Total: RM ${(item.price * quantity).toStringAsFixed(2)}',
                  style: const TextStyle(
                      fontSize: 16, fontWeight: FontWeight.bold)),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                for (int i = 0; i < quantity; i++) {
                  cart.add(item);
                }
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text('Added $quantity ${item.name} to cart'),
                    duration: const Duration(seconds: 2),
                  ),
                );
              },
              child: const Text('Add to Cart'),
            ),
          ],
        ),
      ),
    );
  }
}

class MenuItemCard extends StatelessWidget {
  final MenuItem item;
  final CartProvider cart;
  final VoidCallback onAddToCart;

  const MenuItemCard({
    super.key,
    required this.item,
    required this.cart,
    required this.onAddToCart,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
      ),
      margin: const EdgeInsets.all(4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Image section
          Expanded(
            flex: 3,
            child: ClipRRect(
              borderRadius:
              const BorderRadius.vertical(top: Radius.circular(10)),
              child: item.imageUrl != null && item.imageUrl!.isNotEmpty
                  ? Image.network(
                item.imageUrl!,
                fit: BoxFit.cover,
                width: double.infinity,
                cacheWidth: 200,
                loadingBuilder: (context, child, loadingProgress) {
                  if (loadingProgress == null) return child;
                  return Container(
                    color: Colors.grey[100],
                    child: Center(
                      child: CircularProgressIndicator(
                        value: loadingProgress.expectedTotalBytes != null
                            ? loadingProgress.cumulativeBytesLoaded /
                            loadingProgress.expectedTotalBytes!
                            : null,
                        strokeWidth: 2,
                        color: Colors.orange,
                      ),
                    ),
                  );
                },
                errorBuilder: (context, error, stackTrace) {
                  return Container(
                    color: Colors.grey[100],
                    child: Icon(Icons.fastfood,
                        size: 36, color: Colors.grey[400]),
                  );
                },
              )
                  : Container(
                color: Colors.grey[100],
                child: Icon(Icons.fastfood,
                    size: 36, color: Colors.grey[400]),
              ),
            ),
          ),
          // Info section
          Expanded(
            flex: 2,
            child: Padding(
              padding: const EdgeInsets.all(8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    item.name,
                    style: const TextStyle(
                        fontWeight: FontWeight.bold, fontSize: 13),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  Text(
                    'RM ${item.price.toStringAsFixed(2)}',
                    style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.orange,
                        fontSize: 14),
                  ),
                  SizedBox(
                    width: double.infinity,
                    height: 30,
                    child: ElevatedButton(
                      onPressed: onAddToCart,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.orange,
                        foregroundColor: Colors.white,
                        padding: EdgeInsets.zero,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(5),
                        ),
                      ),
                      child: const Text('ADD TO CART',
                          style: TextStyle(
                              fontSize: 10, fontWeight: FontWeight.bold)),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}