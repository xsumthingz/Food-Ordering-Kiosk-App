import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/cart_provider.dart';
import '../services/firestore_service.dart';
import 'order_success_page.dart';

class CheckoutPage extends StatefulWidget {
  static const route = '/checkout';
  const CheckoutPage({super.key});

  @override
  State<CheckoutPage> createState() => _CheckoutPageState();
}

class _CheckoutPageState extends State<CheckoutPage> {
  String _paymentMethod = 'cash';
  bool _showQRCode = false;

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();
    return Scaffold(
      appBar: AppBar(title: const Text('Checkout')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Order Summary', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            ...cart.items.map((item) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                Expanded(
                  child: Text('${item.item.name} × ${item.qty}'),
                ),
                Text('RM ${item.lineTotal.toStringAsFixed(2)}'),
              ]),
            )).toList(),
            const Divider(),
            _buildTotalRow('Subtotal', cart.subtotal),
            _buildTotalRow('Tax (10%)', cart.tax()),
            _buildTotalRow('Total', cart.total(), isBold: true),
            const SizedBox(height: 24),

            const Text('Payment Method', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),

            RadioListTile(
              value: 'cash',
              groupValue: _paymentMethod,
              title: const Text('Cash'),
              onChanged: (v) => setState(() {
                _paymentMethod = v!;
                _showQRCode = false;
              }),
            ),

            RadioListTile(
              value: 'card',
              groupValue: _paymentMethod,
              title: const Text('Card'),
              onChanged: (v) => setState(() {
                _paymentMethod = v!;
                _showQRCode = false;
              }),
            ),

            RadioListTile(
              value: 'qr',
              groupValue: _paymentMethod,
              title: const Text('QR Payment'),
              onChanged: (v) => setState(() {
                _paymentMethod = v!;
                _showQRCode = true;
              }),
            ),

            // Payment Method Notices
            const SizedBox(height: 16),
            if (_paymentMethod == 'cash') ...[
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.blue[50],
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.blue[200]!),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Row(
                      children: [
                        Icon(Icons.payments, color: Colors.blue, size: 24),
                        SizedBox(width: 8),
                        Text(
                          'Cash Payment Instructions',
                          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.blue),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Text(
                      '1. Go to the cashier counter to make payment',
                      style: TextStyle(fontSize: 14, color: Colors.blue[800]),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      '2. Show your order number to the cashier',
                      style: TextStyle(fontSize: 14, color: Colors.blue[800]),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      '3. Food preparation will begin once payment is confirmed',
                      style: TextStyle(fontSize: 14, color: Colors.blue[800]),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      '4. Admin will verify and update order status',
                      style: TextStyle(fontSize: 14, color: Colors.blue[800]),
                    ),
                    const SizedBox(height: 12),
                    Divider(color: Colors.blue[200]),
                    const SizedBox(height: 8),
                    Text(
                      'Note: Order verification is done by admin on the admin panel → Recent Orders',
                      style: TextStyle(fontSize: 12, fontStyle: FontStyle.italic, color: Colors.blue[700]),
                    ),
                  ],
                ),
              ),
            ] else if (_paymentMethod == 'card') ...[
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.green[50],
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.green[200]!),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Row(
                      children: [
                        Icon(Icons.credit_card, color: Colors.green, size: 24),
                        SizedBox(width: 8),
                        Text(
                          'Card Payment',
                          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.green),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Pay with your credit/debit card at the card machine',
                      style: TextStyle(fontSize: 14, color: Colors.green[800]),
                    ),
                  ],
                ),
              ),
            ],

            // QR Code Display
            if (_showQRCode) ...[
              const SizedBox(height: 20),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.grey[50],
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.grey[300]!),
                ),
                child: Column(
                  children: [
                    const Text('Scan QR Code to Pay', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 12),
                    const Text('Amount: ', style: TextStyle(fontSize: 14)),
                    Text('RM ${cart.total().toStringAsFixed(2)}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.orange)),
                    const SizedBox(height: 16),

                    // Simple QR Code Display
                    Container(
                      width: 200,
                      height: 200,
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.grey[300]!),
                      ),
                      child: Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.qr_code, size: 100, color: Colors.black),
                            const SizedBox(height: 10),
                            const Text(
                              'MANIMALA CATERING',
                              style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                            ),
                            const Text(
                              'QR Payment',
                              style: TextStyle(fontSize: 10, color: Colors.grey),
                            ),
                          ],
                        ),
                      ),
                    ),

                    const SizedBox(height: 16),
                    const Text('Use any QR payment app to scan', style: TextStyle(fontSize: 12, color: Colors.grey)),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.phone_android, size: 16, color: Colors.grey[600]),
                        const SizedBox(width: 4),
                        Icon(Icons.qr_code_scanner, size: 16, color: Colors.grey[600]),
                        const SizedBox(width: 4),
                        Icon(Icons.credit_card, size: 16, color: Colors.grey[600]),
                      ],
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.orange[50],
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Row(
                  children: [
                    Icon(Icons.info, color: Colors.orange, size: 20),
                    SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'After scanning QR code, tap "CONFIRM QR PAYMENT" below',
                        style: TextStyle(fontSize: 12, color: Colors.orange),
                      ),
                    ),
                  ],
                ),
              ),
            ],

            const SizedBox(height: 30),

            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () async {
                  try {
                    final result = await FirestoreService.createOrder(
                        cart: cart.items,
                        total: cart.total(),
                        paymentMethod: _paymentMethod
                    );

                    cart.clear();

                    // Navigate to success page with order number
                    Navigator.pushReplacementNamed(
                      context,
                      OrderSuccessPage.route,
                      arguments: result['orderNumber'], // Pass the 4-digit order number
                    );
                  } catch (e) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Error creating order: $e')),
                    );
                  }
                },
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  backgroundColor: Colors.orange,
                  foregroundColor: Colors.white,
                ),
                child: Text(
                  _paymentMethod == 'cash'
                      ? 'CREATE CASH ORDER'
                      : _paymentMethod == 'qr'
                      ? 'CONFIRM QR PAYMENT'
                      : 'PLACE ORDER',
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildTotalRow(String label, double amount, {bool isBold = false}) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 4),
    child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Text(label, style: TextStyle(fontWeight: isBold ? FontWeight.bold : FontWeight.normal)),
      Text('RM ${amount.toStringAsFixed(2)}', style: TextStyle(fontWeight: isBold ? FontWeight.bold : FontWeight.normal)),
    ]),
  );
}