import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class OrdersPage extends StatelessWidget {
  static const route = '/orders';
  const OrdersPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Recent Orders')),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('orders')
            .orderBy('createdAt', descending: true)
            .limit(20)
            .snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());

          final orders = snapshot.data!.docs;
          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: orders.length,
            itemBuilder: (context, index) {
              final order = orders[index];
              final data = order.data() as Map<String, dynamic>;

              return Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('Order #${order.id.substring(0, 8)}',
                              style: const TextStyle(fontWeight: FontWeight.bold)),
                          Chip(
                            label: Text((data['status'] ?? 'received').toUpperCase()),
                            backgroundColor: _getStatusColor(data['status']),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      ...List<Map<String, dynamic>>.from(data['items'] ?? []).map((item) =>
                          Text('• ${item['name']} × ${item['qty']}')
                      ).toList(),
                      const SizedBox(height: 8),
                      Text('Total: RM ${(data['total'] ?? 0).toStringAsFixed(2)}',
                          style: const TextStyle(fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }

  Color _getStatusColor(String? status) {
    switch (status) {
      case 'preparing': return Colors.orange;
      case 'ready': return Colors.green;
      case 'completed': return Colors.grey;
      default: return Colors.blue;
    }
  }
}