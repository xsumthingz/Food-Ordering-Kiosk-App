import 'package:flutter/material.dart';
import 'menu_page.dart';

class OrderSuccessPage extends StatelessWidget {
  static const route = '/success';
  const OrderSuccessPage({super.key});

  @override
  Widget build(BuildContext context) {
    final orderNumber = ModalRoute.of(context)!.settings.arguments as String?;

    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.check_circle, size: 80, color: Colors.green),
              const SizedBox(height: 16),
              const Text('Order Successful!', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
              const SizedBox(height: 16),

              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.orange, width: 2),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  children: [
                    const Text('YOUR ORDER NUMBER', style: TextStyle(fontSize: 14, color: Colors.grey)),
                    const SizedBox(height: 8),
                    Text(
                      '#${orderNumber?.padLeft(4, '0') ?? 'N/A'}',
                      style: const TextStyle(fontSize: 36, fontWeight: FontWeight.bold, color: Colors.orange),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 24),
              const Text('Please wait at your table', style: TextStyle(fontSize: 16)),
              const Text('We will call your number when ready', style: TextStyle(fontSize: 14, color: Colors.grey)),
              const SizedBox(height: 16),

              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.orange[50],
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.access_time, color: Colors.orange),
                    SizedBox(width: 8),
                    Text('Estimated waiting time: 15-20 minutes',
                        style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                  ],
                ),
              ),

              const SizedBox(height: 32),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () => Navigator.pushNamedAndRemoveUntil(context, MenuPage.route, (route) => false),
                  child: const Text('START NEW ORDER', style: TextStyle(fontSize: 16)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}