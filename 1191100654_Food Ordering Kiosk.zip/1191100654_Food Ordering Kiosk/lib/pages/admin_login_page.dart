import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'admin_page.dart';

class AdminLoginPage extends StatefulWidget {
  const AdminLoginPage({super.key});

  @override
  State<AdminLoginPage> createState() => _AdminLoginPageState();
}

class _AdminLoginPageState extends State<AdminLoginPage> {
  final TextEditingController adminIdController = TextEditingController();
  bool isLoading = false;

  Future<void> _loginAdmin() async {
    setState(() => isLoading = true);

    final adminId = adminIdController.text.trim();

    try {
      final doc = await FirebaseFirestore.instance
          .collection('admins')
          .doc(adminId) // directly check docId
          .get();

      if (doc.exists) {
        // ✅ Login success → go to AdminPage
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const AdminPage()),
        );
      } else {
        // ❌ Invalid ID
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Invalid Admin ID")),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error: $e")),
      );
    }

    setState(() => isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Admin Login")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: adminIdController,
              decoration: const InputDecoration(
                labelText: "Enter 4-digit Admin ID",
              ),
              keyboardType: TextInputType.number,
              maxLength: 4,
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: isLoading ? null : _loginAdmin,
              child: isLoading
                  ? const CircularProgressIndicator(color: Colors.white)
                  : const Text("Login"),
            ),
          ],
        ),
      ),
    );
  }
}
