import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/menu_item.dart';
import '../services/firestore_service.dart';

class AdminPage extends StatefulWidget {
  static const route = '/admin';
  const AdminPage({super.key});

  @override
  State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _showAddMenuDialog() async {
    final name = TextEditingController();
    final price = TextEditingController();
    final imageUrl = TextEditingController();
    bool isActive = true;
    bool saving = false;
    String selectedCategory = 'food';

    await showDialog(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          title: const Text('Add Menu Item'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: name, decoration: const InputDecoration(labelText: 'Name')),
              const SizedBox(height: 8),
              TextField(
                controller: price,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'Price'),
              ),
              const SizedBox(height: 8),
              TextField(controller: imageUrl, decoration: const InputDecoration(labelText: 'Image URL (optional)')),
              const SizedBox(height: 8),
              DropdownButtonFormField<String>(
                initialValue: selectedCategory,
                decoration: const InputDecoration(labelText: 'Category'),
                items: [
                  DropdownMenuItem(value: 'food', child: Text('Food')),
                  DropdownMenuItem(value: 'combos', child: Text('Combos')),
                  DropdownMenuItem(value: 'fried items', child: Text('Fried items')),
                  DropdownMenuItem(value: 'beverage', child: Text('Beverage')),
                ],
                onChanged: (value) {
                  setState(() => selectedCategory = value!);
                },
              ),
              const SizedBox(height: 8),
              Row(children: [const Text('Available'), const Spacer(), Switch(value: isActive, onChanged: (v) => setState(() => isActive = v))]),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
            ElevatedButton(
              onPressed: saving ? null : () async {
                if (name.text.isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Please enter a name')),
                  );
                  return;
                }

                final priceValue = double.tryParse(price.text);
                if (priceValue == null || priceValue <= 0) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Please enter a valid price')),
                  );
                  return;
                }

                setState(() => saving = true);
                try {
                  await FirestoreService.addMenuItem(
                    name: name.text,
                    price: priceValue,
                    isActive: isActive,
                    imageUrl: imageUrl.text.isEmpty ? null : imageUrl.text,
                    category: selectedCategory,
                  );
                  Navigator.pop(context);
                } catch (e) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Error saving: $e')),
                  );
                } finally {
                  setState(() => saving = false);
                }
              },
              child: saving ? const CircularProgressIndicator() : const Text('Save'),
            ),
          ],
        ),
      ),
    );
  }

  Color _getStatusColor(String? status) {
    switch (status) {
      case 'preparing': return Colors.orange;
      case 'ready': return Colors.green;
      case 'completed': return Colors.grey;
      default: return Colors.blue;
    }
  }

  Color _getPaymentColor(bool? isPaid) {
    if (isPaid == true) return Colors.green;
    if (isPaid == false) return Colors.red;
    return Colors.grey;
  }

  String _getPaymentText(bool? isPaid) {
    if (isPaid == true) return 'PAID';
    if (isPaid == false) return 'NOT PAID';
    return 'PENDING';
  }

  void _showOrderDetails(DocumentSnapshot order) {
    final data = order.data() as Map<String, dynamic>;
    final items = List<Map<String, dynamic>>.from(data['items'] ?? []);
    final status = data['status'] ?? 'received';
    final paymentMethod = data['paymentMethod'] ?? 'cash';
    final isPaid = data['isPaid'] ?? false;
    final orderNumber = data['orderNumber'] ?? 'N/A';

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          title: Text('Order #$orderNumber'),
          content: SizedBox(
            width: double.maxFinite,
            height: 550,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Order Info
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Time: ${_formatTimestamp(data['createdAt'])}'),
                    Text('Payment Method: ${paymentMethod.toUpperCase()}'),
                    Row(
                      children: [
                        const Text('Payment Status: '),
                        Chip(
                          label: Text(
                            _getPaymentText(isPaid),
                            style: const TextStyle(fontSize: 12, color: Colors.white),
                          ),
                          backgroundColor: _getPaymentColor(isPaid),
                        ),
                      ],
                    ),
                    Text('Order Status: ${status.toUpperCase()}'),
                  ],
                ),
                const Divider(),

                // Items
                const Text('Items:', style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Expanded(
                  child: ListView.builder(
                    shrinkWrap: true,
                    itemCount: items.length,
                    itemBuilder: (context, index) {
                      final item = items[index];
                      return ListTile(
                        contentPadding: EdgeInsets.zero,
                        leading: CircleAvatar(
                          backgroundColor: Colors.orange[100],
                          child: Text('${item['qty']}'),
                        ),
                        title: Text(item['name']),
                        trailing: Text('RM ${(item['price'] * item['qty']).toStringAsFixed(2)}'),
                      );
                    },
                  ),
                ),
                const Divider(),

                // Total
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('TOTAL:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                    Text('RM ${(data['total'] ?? 0).toStringAsFixed(2)}',
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: Colors.orange)),
                  ],
                ),
                const SizedBox(height: 16),

                // CASH PAYMENT VERIFICATION (only show for cash payments)
                if (paymentMethod == 'cash') ...[
                  const Text('Cash Payment Verification:', style: TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      ElevatedButton(
                        onPressed: isPaid == true ? null : () {
                          FirestoreService.updatePaymentStatus(order.id, true);
                          Navigator.pop(context);
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('✅ Marked as PAID')),
                          );
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                        ),
                        child: const Text('MARK AS PAID'),
                      ),
                      ElevatedButton(
                        onPressed: isPaid == false ? null : () {
                          FirestoreService.updatePaymentStatus(order.id, false);
                          Navigator.pop(context);
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('❌ Marked as NOT PAID')),
                          );
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.red,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        ),
                        child: const Text('MARK AS NOT PAID'),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                ],

                // ORDER STATUS UPDATE
                const Text('Update Order Status:', style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _buildStatusButton('received', 'Received', status, order.id),
                    _buildStatusButton('preparing', 'Preparing', status, order.id),
                    _buildStatusButton('ready', 'Ready', status, order.id),
                    _buildStatusButton('completed', 'Completed', status, order.id),
                  ],
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Close'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatusButton(String statusValue, String label, String currentStatus, String orderId) {
    return ElevatedButton(
      onPressed: currentStatus == statusValue ? null : () {
        FirestoreService.updateOrderStatus(orderId, statusValue);
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Order status updated to $label')),
        );
      },
      style: ElevatedButton.styleFrom(
        backgroundColor: _getStatusColor(statusValue),
        foregroundColor: Colors.white,
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
      ),
      child: Text(label, style: const TextStyle(fontSize: 12)),
    );
  }

  String _formatTimestamp(dynamic timestamp) {
    if (timestamp == null) return 'Just now';
    if (timestamp is Timestamp) {
      return timestamp.toDate().toString().substring(0, 16);
    }
    return 'Just now';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Admin Panel'),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(icon: Icon(Icons.restaurant_menu), text: 'Menu'),
            Tab(icon: Icon(Icons.list_alt), text: 'Orders'),
          ],
        ),
      ),
      floatingActionButton: _tabController.index == 0
          ? FloatingActionButton(
        onPressed: _showAddMenuDialog,
        child: const Icon(Icons.add),
      )
          : null,
      body: TabBarView(
        controller: _tabController,
        children: [
          // Tab 1: Menu Management
          StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance.collection('menu').orderBy('name').snapshots(),
            builder: (context, snapshot) {
              if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
              final items = snapshot.data!.docs.map((doc) => MenuItem.fromMap(doc.id, doc.data() as Map<String, dynamic>)).toList();
              return ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: items.length,
                itemBuilder: (context, index) {
                  final item = items[index];
                  return Card(
                    child: ListTile(
                      leading: item.imageUrl != null && item.imageUrl!.isNotEmpty
                          ? Image.network(
                        item.imageUrl!,
                        width: 40,
                        height: 40,
                        fit: BoxFit.cover,
                        loadingBuilder: (context, child, loadingProgress) {
                          if (loadingProgress == null) return child;
                          return SizedBox(
                            width: 40,
                            height: 40,
                            child: const CircularProgressIndicator(),
                          );
                        },
                        errorBuilder: (context, error, stackTrace) {
                          return const Icon(Icons.fastfood);
                        },
                      )
                          : const Icon(Icons.fastfood),
                      title: Text(item.name),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('RM ${item.price.toStringAsFixed(2)}'),
                          if (item.category != null)
                            Chip(
                              label: Text(item.category!.toUpperCase(), style: const TextStyle(fontSize: 10)),
                              backgroundColor: Colors.orange[100],
                            ),
                        ],
                      ),
                      trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                        Switch(value: item.isActive, onChanged: (v) => FirestoreService.updateAvailability(item.id, v)),
                        IconButton(icon: const Icon(Icons.delete, color: Colors.red), onPressed: () => FirestoreService.deleteMenuItem(item.id)),
                      ]),
                    ),
                  );
                },
              );
            },
          ),

          // Tab 2: Order Management
          StreamBuilder<QuerySnapshot>(
            stream: FirebaseFirestore.instance.collection('orders').orderBy('createdAt', descending: true).snapshots(),
            builder: (context, snapshot) {
              if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
              final orders = snapshot.data!.docs;

              if (orders.isEmpty) {
                return const Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.receipt_long, size: 64, color: Colors.grey),
                      SizedBox(height: 16),
                      Text('No orders yet', style: TextStyle(fontSize: 18, color: Colors.grey)),
                    ],
                  ),
                );
              }

              return ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: orders.length,
                itemBuilder: (context, index) {
                  final order = orders[index];
                  final data = order.data() as Map<String, dynamic>;
                  final timestamp = data['createdAt'];
                  final timeText = _formatTimestamp(timestamp);
                  final paymentMethod = data['paymentMethod'] ?? 'cash';
                  final total = data['total'] ?? 0;
                  final status = data['status'] ?? 'received';
                  final isPaid = data['isPaid'] ?? false;
                  final orderNumber = data['orderNumber'] ?? 'N/A';

                  return Card(
                    margin: const EdgeInsets.only(bottom: 12),
                    child: ListTile(
                      onTap: () => _showOrderDetails(order),
                      leading: CircleAvatar(
                        backgroundColor: _getStatusColor(status),
                        child: Text(orderNumber, style: const TextStyle(fontSize: 10, color: Colors.white)),
                      ),
                      title: Text('Order #$orderNumber'),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('RM ${total.toStringAsFixed(2)} • ${paymentMethod.toUpperCase()}'),
                          Row(
                            children: [
                              Text(timeText, style: const TextStyle(fontSize: 12, color: Colors.grey)),
                              if (paymentMethod == 'cash') ...[
                                const SizedBox(width: 8),
                                Chip(
                                  label: Text(
                                    _getPaymentText(isPaid),
                                    style: const TextStyle(fontSize: 8, color: Colors.white),
                                  ),
                                  backgroundColor: _getPaymentColor(isPaid),
                                  padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 0),
                                ),
                              ],
                            ],
                          ),
                        ],
                      ),
                      trailing: FittedBox(
                        fit: BoxFit.scaleDown,
                        child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Chip(
                            label: Text(status.toUpperCase(), style: const TextStyle(fontSize: 10)),
                            backgroundColor: _getStatusColor(status),
                          ),
                          if (paymentMethod == 'cash' && !isPaid)
                            Container(
                              margin: const EdgeInsets.only(top: 4),
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                              decoration: BoxDecoration(
                                color: Colors.red[50],
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(color: Colors.red),
                              ),
                              child: const Text(
                                'CASH PENDING',
                                style: TextStyle(fontSize: 8, color: Colors.red, fontWeight: FontWeight.bold),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),

                        ],
                      ),
                    ),
                    ),
                  );
                },
              );
            },
          ),
        ],
      ),
    );
  }
}