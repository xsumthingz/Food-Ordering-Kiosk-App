import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:provider/provider.dart';
import 'pages/welcome_page.dart';
import 'pages/menu_page.dart';
import 'pages/admin_page.dart';
import 'pages/cart_page.dart';
import 'pages/checkout_page.dart';
import 'pages/order_success_page.dart';
import 'providers/cart_provider.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(
    MultiProvider(
      providers: [ChangeNotifierProvider(create: (_) => CartProvider())],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'MANIMALA CATERING',
      theme: ThemeData(
        primarySwatch: Colors.orange,
        useMaterial3: true,
        fontFamily: 'Roboto',
      ),
      initialRoute: WelcomePage.route,
      routes: {
        WelcomePage.route: (_) => const WelcomePage(),
        MenuPage.route: (_) => const MenuPage(),
        AdminPage.route: (_) => const AdminPage(),
        CartPage.route: (_) => const CartPage(),
        CheckoutPage.route: (_) => const CheckoutPage(),
        OrderSuccessPage.route: (_) => const OrderSuccessPage(),
      },
    );
  }
}