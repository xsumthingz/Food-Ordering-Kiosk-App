import 'package:flutter/material.dart';
import '../models/cart_item.dart';
import '../models/menu_item.dart';

class CartProvider extends ChangeNotifier {
  final List<CartItem> _items = [];
  List<CartItem> get items => List.unmodifiable(_items);

  void add(MenuItem item) {
    final index = _items.indexWhere((c) => c.item.id == item.id);
    if (index >= 0) {
      _items[index].qty += 1;
    } else {
      _items.add(CartItem(item: item));
    }
    notifyListeners();
  }

  void removeOne(String itemId) {
    final index = _items.indexWhere((c) => c.item.id == itemId);
    if (index >= 0) {
      if (_items[index].qty > 1) {
        _items[index].qty -= 1;
      } else {
        _items.removeAt(index);
      }
      notifyListeners();
    }
  }

  void clear() {
    _items.clear();
    notifyListeners();
  }

  double get subtotal => _items.fold(0.0, (sum, item) => sum + item.lineTotal);
  double tax() => subtotal * 0.10;
  double total() => subtotal + tax();
}